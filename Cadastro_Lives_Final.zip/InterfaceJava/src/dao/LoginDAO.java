/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.LoginController;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Espectador_Seguidor;
import model.Login;
import model.LoginSeguidor;

/**
 *
 * @author diego
 */
public class LoginDAO {
    
    public void consultarLogin(Login login){
        
        try(Connection conectar = new ConnectionMVC().getConnection()){
            
            String sql = "SELECT usuario, senha FROM streamer WHERE usuario = '"+login.getUsuario()+"' AND senha = '"+login.getSenha()+"'";
            PreparedStatement stm = conectar.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            Login login1 = new Login();
            while(rs.next()){
                login1.setUsuario(rs.getString("usuario"));
                login1.setSenha(rs.getString("senha"));
            }
            if(login1.getUsuario() == null && login1.getSenha() == null){
                consultarLoginSeguidor(login);
            }else{
            LoginController lC = new LoginController();
            lC.validarLogin(login, login1);
            }
              
            
        }catch(SQLException e){
            throw new RuntimeException (e);
        }
        
    }
    
    public void consultarLoginSeguidor(Login loginSeguidor){
          try(Connection conectar = new ConnectionMVC().getConnection()){
            
            String sql = "SELECT usuario, senha FROM espectador_seguidor WHERE usuario = '"+loginSeguidor.getUsuario()+"' AND senha = '"+loginSeguidor.getSenha()+"'";
            PreparedStatement stm = conectar.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            Login loginSeguidor1 = new Login();
            while(rs.next()){
                loginSeguidor1.setUsuario(rs.getString("usuario"));
                loginSeguidor1.setSenha(rs.getString("senha"));
            }
            
            LoginController lC = new LoginController();
            lC.validarLoginSeguidor(loginSeguidor, loginSeguidor1);
              
            
        }catch(SQLException e){
            throw new RuntimeException (e);
        }
        
    }
}
