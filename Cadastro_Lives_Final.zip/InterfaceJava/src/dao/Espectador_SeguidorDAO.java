/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Espectador_Seguidor;

/**
 *
 * @author diego
 */
public class Espectador_SeguidorDAO {
    public void cadastrarSeguidor(Espectador_Seguidor seguidor) throws ExceptionDAO {
        
        String sql = "insert into espectador_seguidor (nome, email, usuario, senha, dt_cadastro) value (?,?,?,?,?)";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        try {
            connection = new ConnectionMVC().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, seguidor.getNome());
            pStatement.setString(2, seguidor.getEmail());
            pStatement.setString(3, seguidor.getUsuario());
            pStatement.setString(4, seguidor.getSenha());
            Date data = new Date(System.currentTimeMillis());
            java.sql.Date dt_sql = new java.sql.Date(data.getTime());
            pStatement.setDate(5, dt_sql);
            pStatement.execute();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao cadastrar seguidor: " + e); 
        } finally {
            try{
                if (pStatement != null) {pStatement.close();}  
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao fechar o Statement: " + e);
        } try {
            if (connection != null) {connection.close();}
    } catch (SQLException e) {
        throw new ExceptionDAO ("Erro ao fechar a conexão: " + e);
    }
        }   
    } 
    
    public void alterarEmail(Espectador_Seguidor seguidor) throws ExceptionDAO {
        String sql = "update espectador_seguidor set email = ? where id_user = 1";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        try {
            connection = new ConnectionMVC().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, seguidor.getEmail());
            pStatement.execute();
    } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao cadastrar seguidor: " + e); 
        } finally {
            try{
                if (pStatement != null) {pStatement.close();}  
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao fechar o Statement: " + e);
        } try {
            if (connection != null) {connection.close();}
    } catch (SQLException e) {
        throw new ExceptionDAO ("Erro ao fechar a conexão: " + e);
    }
        } 
    
    
      
}
    public void removerSeguidor(Espectador_Seguidor seguidor) throws ExceptionDAO {
        
        String sql = "delete from espectador_seguidor where id_user = ?";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        try {
            connection = new ConnectionMVC().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setInt(1, seguidor.getId_user());
            pStatement.execute();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao deletar seguidor: " + e); 
        } finally {
            try{
                if (pStatement != null) {pStatement.close();}  
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao fechar o Statement: " + e);
        } try {
            if (connection != null) {connection.close();}
    } catch (SQLException e) {
        throw new ExceptionDAO ("Erro ao fechar a conexão: " + e);
    }
        }   
    }
    
    
}
