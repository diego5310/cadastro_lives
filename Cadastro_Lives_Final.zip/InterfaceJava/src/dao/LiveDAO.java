/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import model.Live;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author diego
 */
public class LiveDAO {
    public void configTitulo(Live live) throws ExceptionDAO {
        
        String sql = "update live set titulo = ? where id_streamer =  1";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        try {
            connection = new ConnectionMVC().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, live.getTitulo());
            pStatement.execute();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao aplicar o título: " + e); 
        } finally {
            try{
                if (pStatement != null) {pStatement.close();}  
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao fechar o Statement: " + e);
        } try {
            if (connection != null) {connection.close();}
    } catch (SQLException e) {
        throw new ExceptionDAO ("Erro ao fechar a conexão: " + e);
    }
        }   
    } 
    
    public void configCategoria(Live live) throws ExceptionDAO {
        String sql = "update live set id_categ = ? where id_live = 1";
        PreparedStatement pStatement = null;
        Connection connection = null;
        
        try {
            connection = new ConnectionMVC().getConnection();
            pStatement = connection.prepareStatement(sql);
            pStatement.setInt(1, live.getId_categ());
            pStatement.execute();
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao alterar Categoria: " + e); 
        } finally {
            try{
                if (pStatement != null) {pStatement.close();}  
        } catch (SQLException e) {
            throw new ExceptionDAO("Erro ao fechar o Statement: " + e);
        } try {
            if (connection != null) {connection.close();}
    } catch (SQLException e) {
        throw new ExceptionDAO ("Erro ao fechar a conexão: " + e);
    }
        }
    }
        
    }
    

