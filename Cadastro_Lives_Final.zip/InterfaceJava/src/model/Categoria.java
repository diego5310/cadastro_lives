/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import dao.ExceptionDAO;
import java.util.ArrayList;

/**
 *
 * @author diego
 */
public class Categoria {
    public Integer id_categ;
    public String nome;
    private ArrayList<Live> lives = new ArrayList<Live>();

    public Categoria(Integer id_categ, String nome) {
        this.id_categ = id_categ;
        this.nome = nome;
    }
public Categoria(){
    
}

    public Categoria(String nome) {
        this.nome = nome;
    }
    public Integer getId_categ() {
        return id_categ;
    }

    public void setId_categ(Integer id_categ) {
        this.id_categ = id_categ;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Live> getLives() {
        return lives;
    }

    public void setLives(ArrayList<Live> lives) {
        this.lives = lives;
    }

    
public void configCateg(Categoria categoria) {
    
    
}
    
    
}
