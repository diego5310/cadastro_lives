/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import dao.ExceptionDAO;
import dao.LiveDAO;
import java.util.ArrayList;

/**
 *
 * @author diego
 */
public class Live {

   
    private Integer id_live;
    public  Integer id_categ;
    public String titulo;
    private Integer id_streamer;
    private ArrayList<Bot> bots = new ArrayList<Bot>();
    private ArrayList<Espectador> espectadores = new ArrayList<Espectador> ();
    private static Live uniqueInstance;
    

    public Live(Integer id_live, Integer id_categ, String titulo, Integer id_streamer) {
        this.id_live = id_live;
        this.id_categ = id_categ;
        this.titulo = titulo;
        this.id_streamer = id_streamer;
    }
    public Live(){
        
    } 
    
    public static synchronized Live getInstance() {
        if (uniqueInstance == null)
            uniqueInstance = new Live();
        
        return uniqueInstance;
    }

    public Live(String titulo) {
        this.titulo = titulo;
    }
    

    public Integer getId_live() {
        return id_live;
    }

    public void setId_live(Integer id_live) {
        this.id_live = id_live;
    }

    public Integer getId_categ() {
        return id_categ;
    }

    public void setId_categ(Integer id_categ) {
        this.id_categ = id_categ;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Integer getId_streamer() {
        return id_streamer;
    }

    public void setId_streamer(Integer id_streamer) {
        this.id_streamer = id_streamer;
    }

    public ArrayList<Bot> getBots() {
        return bots;
    }

    public void setBots(ArrayList<Bot> bots) {
        this.bots = bots;
    }

    public ArrayList<Espectador> getEspectadores() {
        return espectadores;
    }

    public void setEspectadores(ArrayList<Espectador> espectadores) {
        this.espectadores = espectadores;
    }

    

    
public void configTitulo (Live live) throws ExceptionDAO {
    new LiveDAO().configTitulo(live);
    
    
} 

public void configCategoria (Live live) throws ExceptionDAO {
    new LiveDAO().configCategoria(live);
}

    
}   
    

