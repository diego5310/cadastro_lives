/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ExceptionDAO;
import model.Live;

/**
 *
 * @author diego
 */
public class LiveController {
    public boolean configTitulo(String titulo) throws ExceptionDAO {
        
        
        if(titulo != null && titulo.length() > 0){
            Live.getInstance().setTitulo(titulo);
            Live.getInstance().configTitulo(Live.getInstance());
            
            
            
            
            
           
            
            return true;
            
        } 
        return false;
    }
 public boolean configCategoria(int id_categ) throws ExceptionDAO {
     if(id_categ > 0) {
         Live.getInstance().setId_categ(id_categ);
         Live.getInstance().configCategoria(Live.getInstance());
         
         return true;
         
     } return false;
 }   
}
