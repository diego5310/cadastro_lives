/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.LoginDAO;
import javax.swing.JOptionPane;
import model.Login;
import model.LoginSeguidor;
import view.TelaSeguidor;
import view.TelaStreamer;

/**
 *
 * @author diego
 */
public class LoginController {
    
    public boolean inserirLogin(String usuario, String senha){
        
        if(usuario != null && usuario.length() > 0){
            if(senha != null && senha.length() >0){
                Login login = new Login();
                login.setUsuario(usuario);
                login.setSenha(senha);
                
                LoginDAO dao = new LoginDAO();
                dao.consultarLogin(login);
                
                
             return  true;
            }
            JOptionPane.showMessageDialog(null, "Digite a senha !");
            return false;
        }
        
            JOptionPane.showMessageDialog(null, "Digite usuario e senha !");
        
        return false;
    }
    
    
    
       public void validarLogin(Login login, Login login1){
        if(login.getUsuario().equals(login1.getUsuario()) && login.getSenha().equals(login1.getSenha())){
            JOptionPane.showMessageDialog(null, "Bem Vindo");
            TelaStreamer telStr = new TelaStreamer();
            telStr.setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Acesso Negado!");
                
            }
        
        
    
       }  
       
       public void validarLoginSeguidor(Login loginSeguidor, Login loginSeguidor1){
            if(loginSeguidor.getUsuario().equals(loginSeguidor1.getUsuario()) && loginSeguidor.getSenha().equals(loginSeguidor1.getSenha())){
            JOptionPane.showMessageDialog(null, "Bem Vindo");
            TelaSeguidor telseg = new TelaSeguidor();
            telseg.setVisible(true);
            }else{
                JOptionPane.showMessageDialog(null, "Acesso Negado!");
                
            }
            
        }

}
