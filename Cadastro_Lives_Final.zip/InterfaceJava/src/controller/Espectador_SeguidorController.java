/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ExceptionDAO;
import model.Espectador_Seguidor;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

/**
 *
 * @author diego
 */
public class Espectador_SeguidorController {
    public boolean cadastrarSeguidor(String nome, String email, String usuario, String senha) throws ExceptionDAO{
        if(nome != null && nome.length() > 0 && email != null && email.length() > 0 && usuario != null & usuario.length() > 0 && senha != null && senha.length() > 0){
        Espectador_Seguidor.getInstance().setNome(nome);
        Espectador_Seguidor.getInstance().setEmail(email);
        Espectador_Seguidor.getInstance().setUsuario(usuario);
        Espectador_Seguidor.getInstance().setSenha(senha);
        Espectador_Seguidor.getInstance().cadastrarSeguidor(Espectador_Seguidor.getInstance());
        
                    Date date = new Date();
                    Espectador_Seguidor.getInstance().setDt_cadastro(date);
                    
                    System.out.println(Espectador_Seguidor.getInstance().getDt_cadastro());
        return true;
        }
        return false;
    }
 
    
    public boolean alterarEmail(String email) throws ExceptionDAO {
        
        if(email != null && email.length() > 0) {
            Espectador_Seguidor.getInstance().setEmail(email);
            Espectador_Seguidor.getInstance().alterarEmail(Espectador_Seguidor.getInstance());
            
            return true;
        } 
        return false;
    }
    
    public boolean removerSeguidor(int id_user) throws ExceptionDAO {
        if(id_user > 0){
            Espectador_Seguidor.getInstance().setId_user(id_user);
            Espectador_Seguidor.getInstance().removerSeguidor(Espectador_Seguidor.getInstance());
            
            return true;
        } 
        return false;
    }
} 


