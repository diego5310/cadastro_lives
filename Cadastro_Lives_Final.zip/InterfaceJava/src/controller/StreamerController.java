/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.ExceptionDAO;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import model.Streamer;

/**
 *
 * @author diego
 */
public class StreamerController {
    
    public boolean cadastrarStreamer(String nome, String email, String usuario, String senha) throws ExceptionDAO{
        if(nome != null && nome.length() > 0 && email != null && email.length() > 0 && usuario != null & usuario.length() > 0 && senha != null && senha.length() > 0) {
        Streamer.getInstance().setNome(nome);
        Streamer.getInstance().setEmail(email);
        Streamer.getInstance().setUsuario(usuario);
        Streamer.getInstance().setSenha(senha);
        Streamer.getInstance().cadastrarStreamer(Streamer.getInstance());
        
                    Date date = new Date();
                    Streamer.getInstance().setDt_cadastro(date);
                    
                    System.out.println(Streamer.getInstance().getDt_cadastro());
                    
        return true;
        }
            
        return false;
    }
    
    public boolean alterarEmailStm(String email) throws ExceptionDAO {
        
        if(email != null && email.length() > 0) {
            Streamer.getInstance().setEmail(email);
            Streamer.getInstance().alterarEmailStm(Streamer.getInstance());
            
            return true;
        } 
        return false;
    }
    
       
    
}
