/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.Live;

/**
 *
 * @author diego
 */
public class LiveController {
    public boolean configTitulo(String titulo){
        if(titulo != null && titulo.length() > 0){
            Live live = new Live(titulo);
            live.configTitulo(live);
            return true;
            
        } 
        return false;
    }
    
}
