/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.Bot;

/**
 *
 * @author diego
 */
public class BotController {
    public boolean addBot(String nome){
        if(nome != null && nome.length() > 0){
            Bot bot = new Bot(nome);
            bot.addBot(bot);
            return true;
        } 
        return false;
    }
    
}
