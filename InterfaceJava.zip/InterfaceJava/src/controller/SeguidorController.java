/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.Seguidor;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

/**
 *
 * @author diego
 */
public class SeguidorController {
    public boolean cadastrarSeguidor(String nome, String email, String usuario, String senha){
        if(nome != null && nome.length() > 0 && email != null && email.length() > 0 && usuario != null & usuario.length() > 0 && senha != null && senha.length() > 0){
        Seguidor.getInstance().setNome(nome);
        Seguidor.getInstance().setEmail(email);
        Seguidor.getInstance().setUsuario(usuario);
        Seguidor.getInstance().setSenha(senha);
        Seguidor.getInstance().cadastrarSeguidor(Seguidor.getInstance());
        
                    Date date = new Date();
                    Seguidor.getInstance().setDt_cadastro(date);
                    
                    System.out.println(Seguidor.getInstance().getDt_cadastro());
        return true;
        }
        return false;
    }
    
}
