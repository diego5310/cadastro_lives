/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import dao.BotDAO;
import dao.ExceptionDAO;
import java.util.ArrayList;

/**
 *
 * @author diego
 */
public class Bot {
    private String nome;
    private Integer id_bot;
    private ArrayList<Live> lives = new ArrayList<Live>();

    public Bot(String nome, Integer id_bot) {
        this.nome = nome;
        this.id_bot = id_bot;
    }
    public Bot(){
        
    }

    public Bot(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getId_bot() {
        return id_bot;
    }

    public void setId_bot(Integer id_bot) {
        this.id_bot = id_bot;
    }

    public ArrayList<Live> getLives() {
        return lives;
    }

    public void setLives(ArrayList<Live> lives) {
        this.lives = lives;
    }
    
    public void addBot(Bot bot) throws ExceptionDAO {
        new BotDAO().addBot(bot);
        
    }
}
