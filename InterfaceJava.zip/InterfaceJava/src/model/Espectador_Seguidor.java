/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import dao.Espectador_SeguidorDAO;
import dao.ExceptionDAO;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author diego
 */
public class Espectador_Seguidor extends Espectador {
 
    public Espectador_Seguidor(Integer id_user, ArrayList<Live> lives){
        super(id_user, lives);
    }
    
    protected String email;
    protected String usuario;
    protected String senha;
    protected String nome;
    protected Date dt_cadastro;
    private Integer id_bot;
    private static Espectador_Seguidor uniqueInstance;

    public Espectador_Seguidor(String email, String usuario, String senha, String nome, Date dt_cadastro, Integer id_bot, Integer id_user, ArrayList<Live> lives) {
        super(id_user, lives);
        this.email = email;
        this.usuario = usuario;
        this.senha = senha;
        this.nome = nome;
        this.dt_cadastro = dt_cadastro;
        this.id_bot = id_bot;
    }         

    public Espectador_Seguidor(String nome, String email, String usuario, String senha) {
        
        this.nome = nome;
        this.email = email;
        this.usuario = usuario;
        this.senha = senha;
        
        
    }
    private Espectador_Seguidor(){
    }
    public static synchronized Espectador_Seguidor getInstance() {
        if (uniqueInstance == null)
            uniqueInstance = new Espectador_Seguidor();
        return uniqueInstance;
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDt_cadastro() {
        return dt_cadastro;
    }

    public void setDt_cadastro(Date dt_cadastro) {
        this.dt_cadastro = dt_cadastro;
    }

    public Integer getId_bot() {
        return id_bot;
    }

    public void setId_bot(Integer id_bot) {
        this.id_bot = id_bot;
    }

    public static Espectador_Seguidor getUniqueInstance() {
        return uniqueInstance;
    }

    public static void setUniqueInstance(Espectador_Seguidor uniqueInstance) {
        Espectador_Seguidor.uniqueInstance = uniqueInstance;
    }

    
    
    
    public void cadastrarSeguidor(Espectador_Seguidor seguidor) throws ExceptionDAO {
        new Espectador_SeguidorDAO().cadastrarSeguidor(seguidor);
        
        
    }
}
