/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author diego
 */
public class Espectador {
    private Integer id_user;
    private ArrayList<Live> lives = new ArrayList<Live>();

    public Espectador(Integer id_user, ArrayList<Live>lives) {
        this.id_user = id_user;
        this.lives = lives;
    }
    public Espectador(){
        
    }

    public Integer getId_user() {
        return id_user;
    }

    public void setId_user(Integer id_user) {
        this.id_user = id_user;
    }

    public ArrayList<Live> getLives() {
        return lives;
    }

    public void setLives(ArrayList<Live> lives) {
        this.lives = lives;
    }          
}
