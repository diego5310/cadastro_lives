/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;


import dao.ExceptionDAO;
import dao.StreamerDAO;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


/**
 *
 * @author diego
 */
public class Streamer {
   private Integer id_streamer;
   private String nome;
   private String usuario;
   private String senha;
   private Date dt_cadastro;
   private String email;
   private boolean inlive;
   private ArrayList<Live> lives = new ArrayList<Live>();
   private static Streamer uniqueInstance;

    public Streamer(Integer id_streamer, String nome, String usuario, String senha, Date dt_cadastro, String email, boolean inlive) {
        this.id_streamer = id_streamer;
        this.nome = nome;
        this.usuario = usuario;
        this.senha = senha;
        this.dt_cadastro = dt_cadastro;
        this.email = email;
        this.inlive = inlive;
    }

    public Streamer(String nome, String email, String usuario, String senha) {
        this.nome = nome;
        this.email = email;
        this.usuario = usuario;
        this.senha = senha;

    }
    

    public Streamer () {
    }

    public static synchronized Streamer getInstance() {
        if (uniqueInstance == null)
            uniqueInstance = new Streamer();

        return uniqueInstance;
    }

    public Integer getId_streamer() {
        return id_streamer;
    }

    public void setId_streamer(Integer id_streamer) {
        this.id_streamer = id_streamer;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getDt_cadastro() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.format(dt_cadastro);
    }

    public void setDt_cadastro(Date dt_cadastro) {
        this.dt_cadastro = dt_cadastro;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isInlive() {
        return inlive;
    }

    public void setInlive(boolean inlive) {
        this.inlive = inlive;
    }

    public ArrayList<Live> getLives() {
        return lives;
    }

    public void setLives(ArrayList<Live> lives) {
        this.lives = lives;
    }

   public void cadastrarStreamer(Streamer streamer) throws ExceptionDAO {
       new StreamerDAO().cadastrarStreamer(streamer);
       
       
   } 

 
   
}
